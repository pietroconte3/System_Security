import { TripsHistory } from "@/components/dashboard/trips-history";

export default function TripsPage() {
  return <TripsHistory />;
}
